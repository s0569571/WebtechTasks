<?php
require_once 'iDBGruppe01.php';
class PHPDB implements iDBGruppe01{
    private $DSN;
    private $DB_USER;
    private $DB_PW; 
    private $DB_options;
    private $db_Hash;    
    
    public function __construct($DSN, $username, $password) {
        $this->DSN = $DSN;
        $this->DB_USER = $username;
        $this->DB_PW = $password;
        $this->DB_options = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
        $this->db_Hash = null;
    }
    
    public function __destruct() {
        echo "Verbindung getrennt" . PHP_EOL;
    }
    
    public function open() {
        global $Param;
        if(file_exists($Param['serializedFile']) && is_writable($Param['serializedFile'])){
            echo "Daten werden aus Datei geladen." . PHP_EOL;
            $serializedHash = file_get_contents($Param['serializedFile']);
            $this->db_Hash = unserialize($serializedHash);
            echo "Daten geladen." . PHP_EOL;
        }else{
            echo "Datei ${Param['serializedFile']} existiert nicht oder ist nicht beschreibbar." . PHP_EOL;
            echo "Nachfolgende Operationen werden in einer neuen gleichnamigen Datei gespeichert." . PHP_EOL;
            $this->db_Hash = [];
        }
    }
    
    public function close() {
        global $Param;
        $serializedHash = serialize($this->db_Hash);
        file_put_contents($Param['serializedFile'], $serializedHash);
        $this->db_Hash = null;
        echo "Datenbank gesichert - Verbindung abgebaut." . PHP_EOL;
    }
    
    private function deleteId($string){
        for($i = 0; $i<count($this->db_Hash); $i++){
            if(isset($this->db_Hash[$i])){
                $tmpHash = $this->db_Hash[$i];
                if($tmpHash['id'] == $string){
                    unset($this->db_Hash[$i]);
                    echo "Datensatz mit der ID $string entfernt." . PHP_EOL;
                    return true;
                }
            }
                
        }
        echo "Produkt konnte nicht gefunden werden." . PHP_EOL;
    }
    
    private function deletePreis($string){
        for($i=0; $i<count($this->db_Hash); $i++){
            if(isset($this->db_Hash[$i])){
                $tmpHash = $this->db_Hash[$i];

                if($tmpHash['preis'] == $string){
                    echo "Folgendes Hash wird nun geloescht: " . PHP_EOL;
                    echo var_dump($this->db_Hash[$i]) . PHP_EOL;
                    unset($this->db_Hash[$i]);
                    return true;
                }

            }
        }
        echo "Produkt konnte nicht gefunden werden." . PHP_EOL;
    }
    
    private function deleteProdukt($string){
        for($i=0; $i<count($this->db_Hash); $i++){
            if(isset($this->db_Hash[$i])){
                $tmpHash = $this->db_Hash[$i];
                if(strcasecmp($tmpHash['produkt'], $string) == 0){
                    echo "Folgendes Hash wird nun geloescht: " . PHP_EOL;
                    echo var_dump($this->db_Hash[$i]) . PHP_EOL;
                    unset($this->db_Hash[$i]);
                    return true;
                }
            }
        }
        echo "Produkt konnte nicht gefunden werden." . PHP_EOL;
    }

    public function delete($name, $string) {
        echo "Loesche Eintrag [$name=$string]." . PHP_EOL;
        if(strcasecmp($name, "ID") == 0){
            $this->deleteId($name, $string);
        }elseif(strcasecmp($name, "PRODUKT") == 0){
            $this->deleteProdukt($string);
        }elseif(strcasecmp($name, "PREIS") == 0){
            $this->deletePreis($string);
        }
    }
    
    /*
     * Schaut nach, ob Id bereits vorhanden
     */
    private function checkForId($newId){
        foreach($this->db_Hash AS $row){
            if($row['id'] == $newId){
                echo "Die ID $newId ist bereits vergeben" . PHP_EOL;
                return false;
            }
        }
        echo "ID ist in Ordnung." . PHP_EOL;
        return true;
    }
    
    private function getNextId(){
        $id = 0;
        foreach($this->db_Hash AS $row){
            if($row['id'] > $id){
                $id = $row['id'];
            }
        }
        return (1 + $id);
    }

    public function insert($record) {
        echo "Produkt einfuegen." . PHP_EOL;
        if(isset($record['id']) && $this->checkForId($record['id'])){
            $id = $record['id'];
        }else{
            $id = $this->getNextId();
            echo "Neue ID fuer das Produkt: $id" . PHP_EOL;
            $record = ["id" => $id, "produkt" => $record['produkt'], "preis" => $record['preis']];
        }
        
        array_push($this->db_Hash, $record);
        echo "Eintrag mit den Daten ID: ${record['id']} Produkt: ${record['produkt']} Preis: ${record['preis']} eingefuegt." . PHP_EOL;
        
    }
    
    private function queryId($string){
        for($i = 0; $i<count($this->db_Hash); $i++){
            if(isset($this->db_Hash[$i])){
                $tmpHash = $this->db_Hash[$i];
                if($tmpHash['id'] == $string){
                    return $this->db_Hash[$i];
                }
            }
        }
        return null;
    }
    
    private function queryProdukt($string){
        for($i=0; $i<count($this->db_Hash); $i++){
            if(isset($this->db_Hash[$i])){
                $tmpHash = $this->db_Hash[$i];

                if(strcasecmp($tmpHash['produkt'], $string) == 0){
                    return $this->db_Hash[$i];
                }

            }
        }
        return null;
    }
    
    private function queryPreis($string){
        for($i=0; $i<count($this->db_Hash); $i++){
            if(isset($this->db_Hash[$i])){
                $tmpHash = $this->db_Hash[$i];

                if($tmpHash['preis'] == $string){
                    return $this->db_Hash[$i];
                }
            }
        }
        return null;
    }

    public function query($name, $string) {
        echo "Suche nach Eintrag [$name=$string]." . PHP_EOL;
        if(strcasecmp($name, "ID") == 0){
            $queryId = $this->queryId($string);
            if($queryId !== null){
                return $queryId;
            }
            echo "Produkt mit der ID $string existiert nicht." . PHP_EOL;
        }elseif(strcasecmp($name, "PRODUKT") == 0){
            $queryProdukt = $this->queryProdukt($string);
            if($queryProdukt !== null){
                return $queryProdukt;
            }
            echo "Kein passendes Produkt '$string' gefunden" . PHP_EOL;
        }elseif(strcasecmp($name, "PREIS") == 0){
            $queryPreis = $this->queryPreis($string);
            echo "Produkt leider nicht gefunden" . PHP_EOL;
        }
    }

}

?>

<?php
//$test = new PHPDB("test", "user", "");
//$test->open();
//$hash = ["id" => 1, "produkt" => "Schokolade", "preis" => "12.99"];
//$test->insert($hash);
//$hash = ["id" => 2, "produkt" => "Broetchen", "preis" => "2.99"];
//$test->insert($hash);
//$hash = ["id" => 3, "produkt" => "Mandarine", "preis" => "1.99"];
//$test->insert($hash);
//$hash = ["id" => 4, "produkt" => "Schokoladenkuchen", "preis" => "4.99"];
//$test->insert($hash);
//$hash = ["Gruener Tee" => "0.99"];
//$hash = ["id" => 5, "produkt" => "Gruener Tee", "preis" => "0.99"];
//$test->insert($hash);
//$hash = ["id" => 6, "produkt" => "Kaffee", "preis" => "5.99"];
//$test->insert($hash);


//Query:
//$rst = $test->query("PreIs", "0.99");
//echo var_dump($rst) . PHP_EOL;

//Delete:
//$test->delete("iD", "3");
//$rst = $test->query("produkt", "mandarine");
//echo var_dump($rst) . PHP_EOL;
//$test->close();

//$rst = $test->query("id", "0");
//echo var_dump($rst) . PHP_EOL;
//$test->close();
?>