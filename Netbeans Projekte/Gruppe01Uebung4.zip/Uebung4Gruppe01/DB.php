<?php
require_once 'iDBGruppe01.php';
class DB implements iDBGruppe01{
    private $DSN;
    private $DB_USER;
    private $DB_PW; 
    private $DB_options;
    private $db;
    
    public function __construct($DSN, $username, $password) {
        $this->DSN = $DSN;
        $this->DB_USER = $username;
        $this->DB_PW = $password;
        $this->DB_options = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
        $this->db = null;
    }
    
    public function __destruct() {
        echo "Verbindung zur Datenbank getrennt" . PHP_EOL;
    }
    
    public function open() {
        try{
            $this->db = new PDO($this->DSN, $this->DB_USER, $this->DB_PW, $this->DB_options);
            $this->db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);
            $this->db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);
            echo "Verbindung zur Datenbank aufgebaut." . PHP_EOL;
        } catch (PDOException $err) {
            echo 'DB ERROR: ' . $err->getMessage().PHP_EOL;
        }
    }
    
    private function useConnection(){
        if(isset($this->db)){
            return $this->db;
        }else{
            return $this->open();
        }
    }
    
    public function close() {
        echo "Verbindung zur Datenbank wird getrennt." . PHP_EOL;
        $this->db = null;
    }
    
    public function createTableProdukte(){
        $create_table = "CREATE TABLE produkte (";
        $create_table = $create_table . "id int(11) NOT NULL PRIMARY KEY, ";
        $create_table = $create_table . "produkt varchar(45) NOT NULL, ";
        $create_table = $create_table . "preis varchar(30) NOT NULL";
        $create_table = $create_table . ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        
        $rtn = $this->useConnection()->exec($create_table);
        if($rtn === false){
            $err = $this->useConnection()->errorInfo();
            echo 'DB ERROR: #'.$err[1]." ".$err[2].PHP_EOL;
        }else{
            echo "Tabelle Produkte erfolgreich angelegt." . PHP_EOL;
        }
    }
    
    public function dropTable(){
        $drop_table = "DROP TABLE IF EXISTS produkte";
        
        $rtn = $this->useConnection()->exec($drop_table);
        if($rtn === false){
            $err = $this->useConnection()->errorInfo();
            echo 'DB ERROR: #'.$err[1]." ".$err[2].PHP_EOL;
        }else{
            echo "Tabelle Produkte erfolgreich geloescht." . PHP_EOL;
        }
    }

    public function delete($name, $string) {
        $tmpHash = $this->query($name, $string);
        $id = (isset($tmpHash['id'])) ? $tmpHash['id'] : null;

        $query = "DELETE FROM produkte WHERE ID = :id";
        
        $stmt = $this->useConnection()->prepare($query);
        if(!is_null($id)){
            $stmt->bindValue(':id', $string, PDO::PARAM_INT);
        }else{
            echo "Eintrag mit den Werten: " . "[$name = $string]" . 
                    " konnte nicht geloescht werden. Bitte ueberpruefen Sie die Eingabe." . PHP_EOL;
            return;
        }
        
        $stmt->execute();
        return $stmt->rowCount();
    }
    
    private function getNextId(){
        $query = "SELECT MAX(ID) FROM produkte";
        $data = $this->useConnection()->query($query);
        if(($rst = $data->fetch()) !== false){
            echo $rst['MAX(ID)'] . " ist die hoechste vergebene ID" . PHP_EOL;
            echo "Neue ID fuer das Produkt:" . (1 + $rst['MAX(ID)']) . PHP_EOL;
            return (1 + $rst['MAX(ID)']);
        }
    }

    private function checkForId($id){
        $query = "SELECT ID FROM Produkte WHERE ID = :id";
        
        $stmt = $this->useConnection()->prepare($query);
        
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        
        $stmt->execute();
        $row = $stmt->fetch();
        if($row !== false){
            return false;
        }else{
            return true;
        }
    }
    
    public function insert($record) {
        if((isset($record['id'])) && ($this->checkForId($record['id']))){
            $id = $record['id'];
        }else{
            $id = $this->getNextId();
        }
        if(isset($record['produkt'])){
            $produkt = $record['produkt'];
        }
        if(isset($record['preis'])){
            $preis = $record['preis'];
        }
                
        echo "Folgendes Produkt wird hinzugefuegt: ID: " . $id . " Produkt: " . $produkt . " Preis: $preis" . PHP_EOL;

        $insert_query = "INSERT INTO produkte(id, produkt, preis) VALUES(:id, :produkt, :preis)";
        $stmt = $this->useConnection()->prepare($insert_query);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->bindValue(':produkt', $produkt, PDO::PARAM_STR);
        $stmt->bindValue(':preis', $preis, PDO::PARAM_STR);
            
        if($stmt->execute() === true){
            echo "Datensatz (ID: $id, Produkt: $produkt, Preis: $preis) erfolgreich eingefuegt." . PHP_EOL;
        }
        
    }

    public function query($name, $string) {
        $query = "SELECT id, produkt, preis FROM produkte ";
        $query = ((strcasecmp($name, "ID") == 0) ? $query . "WHERE id = :wert" : $query);
        $query = ((strcasecmp($name, "PRODUKT") == 0) ? $query . "WHERE produkt = :wert" : $query);
        $query = ((strcasecmp($name, "PREIS") == 0) ? $query . "WHERE preis = :wert" : $query);

        echo "Query: $query" . PHP_EOL;
        
        $stmt = $this->useConnection()->prepare($query);
        
        if(strcasecmp($string, "ID") == 0){
            $stmt->bindValue(':wert', $string, PDO::PARAM_INT);
        }else{
            $stmt->bindValue(':wert', $string, PDO::PARAM_STR);
        }
        
        $stmt->execute();
        $row = $stmt->fetch();
        if($row === false){
            echo "Leider konnte kein Produkt mit den Werten:". " [$name = $string] " . "gefunden werden." . PHP_EOL;
        }
        return $row;
    }
}
?>