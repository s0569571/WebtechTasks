<?php
namespace parameterDB;
$Param['host'] = "localhost";
$Param['username'] = "root";
$Param['password'] = "";
$Param['dbname'] = "gruppe01uebung4";
$Param['dsn'] = "mysql:host=${Param['host']};dbname=${Param['dbname']}";
$Param['serializedFile'] = "serializedProdukte.txt";
?>