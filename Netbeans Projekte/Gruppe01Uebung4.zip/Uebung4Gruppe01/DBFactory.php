<?php
require_once 'DB.php';
require_once 'PHPDB.php';
class DBFactory {
    static function access($type, $DSN, $username, $password){
        if(strcasecmp($type, "PDODB") == 0){
            echo "Es wird initialisiert: PDODB" . PHP_EOL;
            return new DB($DSN, $username, $password);
        }elseif(strcasecmp($type, "PHPDB") == 0){
            echo "Es wird initialisiert: PHPDB" . PHP_EOL;
            return new PHPDB($DSN, $username, $password);
        }else{
            echo "Achtung: $type ist ein unbekannter Datenbanktyp." . PHP_EOL; 
        }
    }
}
?>