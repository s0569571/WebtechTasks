<?php
/*
 * Tabelle in MYSQL erstellen
 */
$create_table = "CREATE TABLE produkte (";
$create_table = $create_table . "id int(11) NOT NULL PRIMARY KEY, ";
$create_table = $create_table . "produkt varchar(45) NOT NULL, ";
$create_table = $create_table . "preis float(7,2) NOT NULL";
$create_table = $create_table . ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
?>

<?php
/*
 * CSV in MYSQL Datenbank laden:
 */
$load_data = "LOAD DATA INFILE './Lebensmittel.csv ";
$load_data = $load_data . "INTO TABLE produkte ";
$load_data = $load_data . "FIELDS TERMINATED BY ',' ";
$load_data = $load_data . "LINES TERMINATED BY '\n' ";
$load_data = $load_data . "IGNORE 1 ROWS;"
?>

<?php
require_once './myParameter.php';
require_once './DBFactory.php';

static $mysqlCounter = 1;
static $phpCounter = 1;

function printfRowMysql($row){
    global $mysqlCounter;
    if(isset($row['id']) && isset($row['produkt']) && isset($row['preis'])){
       echo "$mysqlCounter. Query ueber die MYSQL Datenbank: " . PHP_EOL;
       printf('%10s ', "ID");
       printf('%10s ', "Produkt");
       printf('%10s ', "Preis");
       echo PHP_EOL;
       printf('%10s ', $row['id']);
       printf('%10s ', $row['produkt']);
       printf('%10s ', $row['preis']);
       echo PHP_EOL;
       $mysqlCounter = $mysqlCounter + 1;
    }
}

function printfRowPhpDb($row){
    global $phpCounter;
    if(isset($row['id']) && isset($row['produkt']) && isset($row['preis'])){
       echo "$phpCounter. Query ueber die simulierte Datenbank im RAM: " . PHP_EOL;
       printf('%10s ', "ID");
       printf('%10s ', "Produkt");
       printf('%10s ', "Preis");
       echo PHP_EOL;
       printf('%10s ', $row['id']);
       printf('%10s ', $row['produkt']);
       printf('%10s ', $row['preis']);
       echo PHP_EOL;
       $phpCounter = $phpCounter + 1;
   }
}

function printfRow($row,$mysql){
    
    if($mysql){
        printfRowMysql($row);
    }else{
        printfRowPhpDb($row);
    }
    
}
?>

<?php
$nulltesProdukt = ["id" => 0, "produkt" => "Broetchen", "preis" => "2.50"];
$erstesProdukt = ["produkt" => "Toilettenpapier", "preis" => "3.99"];
$zweitesProdukt = ["id" => 22, "produkt" => "Desinfektionsmittel", "preis" => "6.99"];
$drittesProdukt = ["produkt" => "Atemmasken", "preis" => "15.99"];

?>

<?php

/*
 * Im nachfolgenden werden Abfragen ueber MYSQL getaetigt
 */
$pdodb = DBFactory::access("pdodb", $Param['dsn'], $Param['username'], $Param['password']);
$pdodb->open();
$pdodb->insert($nulltesProdukt);
$rst = $pdodb->query("id", 0);
printfRow($rst, true);
$pdodb->close();

$pdodb->open();
$pdodb->insert($nulltesProdukt);
$pdodb->delete("produkt", "Broetchen");
$pdodb->insert($erstesProdukt);
$rst = $pdodb->query("preis", "3.99");
printfRow($rst, true);
$pdodb->close();

$pdodb->open();
$pdodb->insert($zweitesProdukt);
$pdodb->delete("id", 1);
$rst = $pdodb->query("id", 1);
printfRow($rst, true);
$pdodb->insert($drittesProdukt);
$rst = $pdodb->query("preis", "15.99");
printfRow($rst, true);
?>

<?php
/*
 * Im nachfolgenden werden Abfragen ueber die simulierte Datenbank im RAM getaetigt
 */
$phpdb = DBFactory::access("phpdb", $Param['dsn'], $Param['username'], $Param['password']);
$phpdb->open();
$rst = $phpdb->query("produkt", "Schokolade");
printfRow($rst, false);
$phpdb->insert($nulltesProdukt);
$rst = $phpdb->query("id", 0);
printfRow($rst, false);
$phpdb->close();

$phpdb->open();
$phpdb->insert($erstesProdukt);
$rst = $phpdb->query("produkt", "toilettenpapier");
printfRow($rst, false);
$phpdb->insert($zweitesProdukt);
$phpdb->close();

$phpdb->open();
$rst = $phpdb->query("Preis", "6.99");
printfRow($rst, false);
$phpdb->insert($drittesProdukt);
$rst = $phpdb->query("id", 3);
printfRow($rst, false);
$phpdb->delete("id", 3);
$rst = $phpdb->query("produkt", "mandarine");
printfRow($rst, false);
$phpdb->close();
?>